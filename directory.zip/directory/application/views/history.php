<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>


	<h1>Directory listing</h1>

	<div id="body">
	
	<table id="datatable" class="history">
	<thead>
         <tr>
                <th>Sl no</th>
				<th>File name</th>
                <th>Uploaded time</th>
				<th>Deleted time</th>
				<th>Status</th>
				
                
            </tr>  
        </thead>
        <tbody>
		<?php $i = 0; if(count($result) > 0) { 
		foreach($result as $rs) {
		?>
		<tr>
		<td><?php echo $i; ?></td>
		<td><?php echo $rs->filename; ?></td>
        <td><?php echo $rs->uploadtime; ?></td>
		<td><?php echo $rs->deletetime; ?></td>
		<td><?php if($rs->status == 0) { echo 'Deleted'; } else { echo 'Active'; } ?></td>
		</tr>
		<?php $i = $i+1; }} ?>
            
		</tbody>
	</table
		
	</div>
	<?php 
	$this->load->view('footer');
	
	?>
	<script>
	function filedelete(file,path)
	{
		if (confirm('Are you sure you want to delete this file'))
		{
			window.location.href = "<?php echo base_url().'Listing/deleteList/'; ?>"+file+'/'+path;
		} else {
			alert('Why did you press cancel? You should have confirmed');
		}
	}
	</script>
	</script>
	<script src="<?php echo base_url()?>asset/js/datatable.js"></script>
	<script>
	$(document).ready(function() {
    $('#datatable').DataTable({
		"pageLength": 20,
		"ordering": false
	});
	
} );
	</script>

	