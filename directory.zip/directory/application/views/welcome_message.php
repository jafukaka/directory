<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>


	<h1>Directory listing</h1>

	<div id="body">
	<?php if($this->session->flashdata('SUCCESSMSG')) { ?>
            <div role="alert" class="alert alert-success">
            
                                           
            <?=$this->session->flashdata('SUCCESSMSG')?>
            </div>
    <?php } ?>
	<table id="datatable">
	<thead>
         <tr>
                <th>Directory</th>
				<th></th>
                <th>Delete file</th>
				
                
            </tr>  
        </thead>
        <tbody>
		<?php echo $list; ?>
            
		</tbody>
	</table
		
	</div>
	<?php 
	$this->load->view('footer');
	
	?>
	<script>
	function filedelete(file,path)
	{
		if (confirm('Are you sure you want to delete this file'))
		{
			window.location.href = "<?php echo base_url().'Listing/deleteList/'; ?>"+file+'/'+path;
		} else {
			alert('Why did you press cancel? You should have confirmed');
		}
	}
	</script>
	</script>
	<script src="<?php echo base_url()?>asset/js/datatable.js"></script>
	<script>
	$(document).ready(function() {
    $('#datatable').DataTable({
		"pageLength": 20,
		"ordering": false
	});
	
} );
	</script>

	