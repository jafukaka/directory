<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->view('header');
?>


	<h1>Upload File</h1>

	<div id="body">
	<?php if($this->session->flashdata('SUCCESSMSG')) { ?>
            <div role="alert" class="alert alert-success">
            
                                           
            <?=$this->session->flashdata('SUCCESSMSG')?>
            </div>
    <?php } ?>
	<?php if($this->session->flashdata('FAILMSG')) { ?>
        <div role="alert" class="alert alert-warning">
        <?=$this->session->flashdata('FAILMSG')?>
        </div>
    <?php } ?>
	<form class="form-horizontal"  method="post" enctype="multipart/form-data">
                                        <div class="form-group">
	<div class="col-md-2 control-label">
		<label> Select file to be uploded maximum 2MB</label>
 	</div>
	<div class="col-md-7">
		
		  <div style="margin-top: 0px; color: red;"><?= form_error('mode'); ?></div>
	</div>

</div>
										
                                        <div class="form-group">
                                            <label class="col-md-2 control-label">Upload file<span class="text-danger">*</span></label>
                                            <div class="col-md-7">
                                                <!--<img id="previewimage" onclick="$('#uploadFile').click();" src="<?php echo base_url(); ?>images/product_image.gif" style="cursor: pointer;height: 210px;width: 210px;position: relative;z-index: 10;"/>-->
                                                <input type="file" id="uploadFile" name="upload"   />
                                                 <div style="margin-top: 0px; color: red;"><?= form_error('errorimage'); ?></div>
<!--                                                <input  type="file" id="uploadFile" name="product_image" required >-->
                                            </div>
                                        </div>
                                        
                                       <div class="form-group">
                                            <div class="col-md-8 col-md-offset-2">
                                                <button class="btn btn-sm btn-primary" name="submit" type="submit"><i class="fa fa-check"></i> Submit</button>
                                            </div>
                                        </div>
                                    </form>
		
	</div>
	<?php 
	$this->load->view('footer');
	
	?>
	
	

	