<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class List_Model extends CI_Model {

     
        public function ListAdd($data)
        {
             $this->db->insert('upload', $data); 
             return TRUE;
        }
		public function DeleteList($name)
        {
			$time = date("Y-m-d h:i:s");
			$data['deletetime'] = $time;
			$data['status'] = 0;
            $this->db->where('filename',$name);
           $query = $this->db->update('upload',$data);
		   return TRUE;
        }
		public function history()
        {
                $this->db->select(" * ");
                $this->db->from('upload');
                $query = $this->db->get();
                return $query->result();
        }
        
         
}
