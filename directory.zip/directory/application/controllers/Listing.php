<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Listing extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function __construct()
	{
            parent::__construct();
            
            
            $this->load->model('List_Model');
           
          /*  if($this->session->email == "")
            {
                redirect('account/login');
            }
            */
	}
	public function index()
	{
		if (empty($_FILES['upload']['name']))
		{
			$this->load->view('upload');
		}
				
           
             
            else
            {	
	
					
				$format = end(explode(".",$_FILES['upload']['name']));
				
				if($format == 'png' || $format == 'jpeg' || $format == 'jpg' || $format == 'gif')
				{
					$upload_path = './uploads/files/images';
				}
				else if($format == 'pdf')
				{
					$upload_path = './uploads/files/pdf';
				}
				else{
					$upload_path = './uploads/files/others';
				}
				  
				  //upload file
				  $config['upload_path'] = $upload_path;
                  
				  $config['allowed_types'] = 'txt|doc|docx|pdf|png|jpeg|jpg|gif';
                  $config['max_size'] = '2048';                 
                  //$config['max_width']= 70246;                
                  //$config['max_height']  = 70246;
                  $this->load->library('upload', $config);
				  $name = time().strtolower($_FILES['upload']['name']);
                  $config['file_name'] = $name;
                  $this->upload->initialize($config);
                  if ( ! $this->upload->do_upload('upload'))
        {
            $error = $this->upload->display_errors();

           $this->session->set_flashdata('FAILMSG',$error);
        }
        else
        {
			$data = array(
                        
                        'filename' => $name,
                        'uploadtime' => date("Y-m-d h:i:s"),
                        'status' => 1
                        
                        
                );
                $insert = $this->List_Model->ListAdd($data);
                $this->session->set_flashdata('SUCCESSMSG','File uploaded successfully');
            
        }
				  
				  
				  
                     
                
                
				//$data['listen_list'] = $this->Book_Model->get_list();
                redirect();
                
            }
	}
	public function details()
	{
		$this->load->helper('directory');
		$map = directory_map('./uploads');
		foreach($map as $key => $ls )  {
			$string ='<tr><td><i class="fa fa-folder"></i><span>';
            $string .= chop($key,"/\/"); 
			$string .= '</span></td><td></td><td></td></tr>';
			if(count($ls) > 0)
			{				
				$path = $key.'.';
				$string .= $this->key_value($ls,0,$path);
				
			}
			
		}
		$data['list'] = $string;
		$this->load->view('header');
		$this->load->view('welcome_message',$data);
		
	}
	public function key_value($ls,$i,$path)
	{
		$string = '';
		
		foreach($ls as $key1 => $ls1 )  {
			$newpath = "";
			if(is_numeric($key1))
			{
				
				$newpath .= $path;
				
				$string.='<tr><td>'.$ls1.'</td><td></td><td><span onclick=filedelete("'.$ls1.'","'.$newpath.'");> <i class="fa fa-trash"></i></span></td></tr>';
			}
			else
			{
				$space ='';
				$newpath .= $path.$key1.'.';
				for($k = $i;$k >= 0; $k--)
				{
					$space .='- ';
				}
				
				$string.='<tr><td>'.$space.'<i class="fa fa-folder"></i><span>'.chop($key1,"/\/").'</span></td><td></td><td></td></tr>';
				if(count($ls1) > 0)
			{			
				
				$string .= $this->key_value($ls1,$j=$i+1,$newpath);
				
			}
			}
			
		}
		return $string;
	}
	public function deleteList($name,$path) 
        {
            $this->List_Model->deleteList($name);
			$path = str_replace(".","/",$path);
			unlink('uploads/'.$path.'/'.$name);
            $this->session->set_flashdata('SUCCESSMSG','file Deleted Successfully from folder!');
			
            redirect('Listing/details');
            
        }
		public function history() 
        {
            $result = $this->List_Model->history();
			$data['result'] = $result;
			$this->load->view('header');	
			$this->load->view('history',$data);		
           
            
        }
}
